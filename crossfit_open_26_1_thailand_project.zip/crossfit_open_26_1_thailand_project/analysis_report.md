# CrossFit Open 26.1 Thailand - Analytical Report

## 1. Analytical framing

This file is **not a full athlete-level leaderboard export**. It is a **rank-aligned score table** with separate columns for men and women:

- `TH Rank`
- men's reps + division
- women's reps + division

That means the dataset supports a strong analysis of:
- participation counts
- score distributions
- rank structure
- competitive depth
- division mix

But it does **not** support:
- athlete-level profiling
- affiliate/gym analysis
- region analysis
- age analysis
- tie-break analysis
- named leaderboard storytelling

The right strategy is to:
1. audit the raw table,
2. reshape it into a clean long-format analytical dataset,
3. analyze what is truly supported,
4. build a lightweight dashboard around score and participation patterns.

## 2. Dataset audit

### Raw schema
- Rows: 308
- Columns: 5

| Column | Raw type | Notes |
|---|---:|---|
| TH Rank | integer | Shared rank column used for both men and women tables |
| Reps Men | integer | Numeric score for men |
| Division | text | Men's division label |
| Reps Women | text | Women's score, mostly numeric but contains `Null` strings |
| Division Women | text | Women's division label |

### Data quality findings
- No true blank cells in the raw CSV, but there are **placeholder strings**:
  - `-` in division columns
  - `Null` in `Reps Women`
- The tail of the file contains **padding rows** after one or both gender tables ended.
- `Foudation` is a spelling inconsistency and should be standardized to `Foundation`.
- The raw file has **30 exact duplicate rows**.  
  Important: these cannot be safely dropped in raw form because some may represent **legitimate tied positions** with identical rank-score-division combinations, and the file has no athlete IDs.

### Missingness / structural issues
- Men's valid rows: 284
- Women's valid rows: 272
- Removed as structural padding:
  - Men: 24 rows
  - Women: 36 rows

### Score parsing
- `Reps Men` was already numeric.
- `Reps Women` required numeric coercion because of `Null` placeholders.
- No time strings or tie-break field are present in this file.
- Scores appear to be **repetition counts**, so no special mixed-format parsing was needed.

## 3. Cleaning decisions

### Transformations applied
1. Split the table into two athlete result tables:
   - men: `TH Rank`, `Reps Men`, `Division`
   - women: `TH Rank`, `Reps Women`, `Division Women`
2. Removed structural padding rows where division was `-`.
3. Renamed and standardized fields:
   - `rank_th`
   - `score_reps`
   - `division`
   - `gender`
4. Standardized category labels:
   - `RX` -> `Rx`
   - `Foudation` -> `Foundation`
5. Converted score to numeric.
6. Added analytical helper columns:
   - `is_rank_tied`
   - `score_z_within_gender_division`
   - `percentile_within_gender`

### Before vs after
- Raw table: 308 rows x 5 columns
- Clean analytical table: 556 rows x 8 columns

### Clean analytical data dictionary
| Column | Type | Meaning |
|---|---|---|
| rank_th | integer | Thailand rank in the provided gender table |
| score_reps | numeric | Workout score in reps |
| division_raw | text | Original division label |
| gender | text | Men / Women |
| division | text | Cleaned division label |
| is_rank_tied | boolean | Whether rank repeats within a gender |
| score_z_within_gender_division | numeric | Standardized score relative to peers in same gender/division |
| percentile_within_gender | numeric | Percentile position within gender based on score |

## 4. Exploratory analysis

### Participation snapshot
- Total valid athlete results: **556**
- Men: **284** (51.1%)
- Women: **272** (48.9%)

Division mix:
- Rx: **443** (79.7%)
- Scaled: **109** (19.6%)
- Foundation: **4** (0.7%)

By gender:
- Men in Rx: **253** (89.1% of men)
- Women in Rx: **190** (69.9% of women)
- Women in Scaled: **79** (29.0% of women)

### Performance distribution
Overall score distribution:
- Min: **59**
- 25th percentile: **155.0**
- Median: **180.0**
- Mean: **184.5**
- 75th percentile: **212.0**
- Max: **317**

By gender:
- Men median: **186.0**
- Women median: **176.0**
- Men max: **289**
- Women max: **317**

### Competitive structure
Depth by group:
- Deepest field: **Men Rx (253 athletes)**
- Second deepest: **Women Rx (190 athletes)**
- Third deepest: **Women Scaled (79 athletes)**

Spread by group (meaningful groups only):
- Men Rx IQR: **56.0**
- Women Rx IQR: **56.8**
- Men Scaled IQR: **31.0**
- Women Scaled IQR: **37.5**

Interpretation:
- Rx fields are both deeper and wider than Scaled.
- Women's Rx has the **widest top-to-median gap**, suggesting a sharper elite tail.

### Percentile cutoffs (score thresholds)
#### Men
- Top 1% cutoff: **274.3**
- Top 5% cutoff: **255.7**
- Top 10% cutoff: **241.1**
- Top 25% cutoff: **215.2**
- Median: **186.0**

#### Women
- Top 1% cutoff: **285.3**
- Top 5% cutoff: **254.4**
- Top 10% cutoff: **236.8**
- Top 25% cutoff: **210.0**
- Median: **176.0**

### Rank dynamics
- Men rows flagged as tied ranks: **20**
- Women rows flagged as tied ranks: **18**

Because there are repeated ranks, the rank ladder is **not strictly one-rank-per-athlete**. This is expected in competition data and should be preserved.

## 5. Key findings

1. **This Thailand 26.1 file is heavily Rx-dominant.** Nearly 80% of valid entries are Rx.
2. **Men have a slightly larger field**, but participation is reasonably balanced (284 vs 272).
3. **Women's top score is higher than men's top score in this file** (317 vs 289), and the women's field shows a larger top-to-median gap (141 vs 103 reps).
4. **Men's Rx is the deepest competitive field**, making it the clearest division for “depth” analysis.
5. **Women's Rx appears the most polarized meaningful field**: strong top scores and broader spread than women's Scaled.
6. **The file structure itself is the main data limitation**. It is useful for score benchmarking, but not for athlete, affiliate, or regional storytelling.

## 6. Visualization plan

### Minimal chart set (best for a quick presentation)
1. **Participation by gender and division**  
   Best for explaining field structure immediately.
2. **Score distribution by gender**  
   Best for showing where most athletes cluster.
3. **Box plot by gender and division**  
   Best for comparing spread, medians, and tails.
4. **Percentile curve**  
   Best for benchmark storytelling (“what score puts you in top 10%?”)
5. **Rank vs score scatter**  
   Best for showing score compression and drop-off across the field.

### Full chart set
- Participation by gender and division
- Score distribution by gender
- Box plot by gender and division
- Percentile curve
- Rank vs score
- Top-10 leaderboard-style table

### Unsupported visuals in this specific file
The following cannot be built from the uploaded CSV because the required columns are absent:
- affiliate leaderboard
- gym performance comparison
- geography map of Thailand
- age-band analysis
- athlete-name leaderboard
- tie-break scatter

## 7. Website / dashboard direction

### Static site works well for this dataset
A GitHub Pages site is ideal because:
- the dataset is small
- charts can be pre-rendered as PNGs
- there is no need for a backend
- the story is mostly fixed once the charts are generated

### Streamlit is useful only if you want filters
A Streamlit app adds value if you want interactive filters for:
- gender
- division
- score bands
- rank ranges

But with this file's limited schema, a static site is probably the fastest, cleanest publishing choice.

## 8. Limits and next improvements

### What cannot be concluded
- You cannot infer training quality of specific gyms.
- You cannot infer geography patterns.
- You cannot compare athletes by age.
- You cannot separate identical score ties into named athletes.

### Best next data upgrade
To unlock a much stronger sports-analytics dashboard, the next file should include:
- athlete name
- affiliate / gym
- province / city
- age or age-group
- official division
- tie-break time
- workout submission status
- Rx / Scaled as explicit field

With those fields, the dashboard becomes much more compelling for athletes and gym communities.
