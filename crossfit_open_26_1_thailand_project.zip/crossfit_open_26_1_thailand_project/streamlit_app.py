import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="CrossFit Open 26.1 Thailand", layout="wide")

@st.cache_data
def load_data(path: str) -> pd.DataFrame:
    return pd.read_csv(path)

df = load_data("cleaned_crossfit_open_26_1_thailand.csv")

st.title("CrossFit Open 26.1 Thailand Dashboard")
st.caption("Lightweight dashboard built from the uploaded rank-and-score table.")

# Sidebar filters
st.sidebar.header("Filters")
gender_filter = st.sidebar.multiselect("Gender", options=sorted(df["gender"].unique()), default=sorted(df["gender"].unique()))
division_filter = st.sidebar.multiselect("Division", options=sorted(df["division"].unique()), default=sorted(df["division"].unique()))
rank_max = int(df["rank_th"].max())
rank_range = st.sidebar.slider("Rank range", min_value=1, max_value=rank_max, value=(1, rank_max))

filtered = df[
    df["gender"].isin(gender_filter)
    & df["division"].isin(division_filter)
    & df["rank_th"].between(rank_range[0], rank_range[1])
].copy()

# KPIs
k1, k2, k3, k4 = st.columns(4)
k1.metric("Athletes", len(filtered))
k2.metric("Median score", f"{filtered['score_reps'].median():.1f}" if len(filtered) else "-")
k3.metric("Average score", f"{filtered['score_reps'].mean():.1f}" if len(filtered) else "-")
k4.metric("Top score", int(filtered['score_reps'].max()) if len(filtered) else "-")

c1, c2 = st.columns(2)

with c1:
    st.subheader("Participation")
    part = filtered.groupby(["gender", "division"]).size().reset_index(name="athletes")
    if len(part):
        fig = px.bar(part, x="gender", y="athletes", color="division", barmode="group")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No rows match the current filters.")

with c2:
    st.subheader("Score distribution")
    if len(filtered):
        fig = px.histogram(filtered, x="score_reps", color="gender", nbins=20)
        st.plotly_chart(fig, use_container_width=True)

c3, c4 = st.columns(2)

with c3:
    st.subheader("Rank vs score")
    if len(filtered):
        fig = px.scatter(filtered, x="rank_th", y="score_reps", color="gender", symbol="division",
                         hover_data=["division", "is_rank_tied"])
        st.plotly_chart(fig, use_container_width=True)

with c4:
    st.subheader("Percentile curve")
    if len(filtered):
        plot_rows = []
        for gender, g in filtered.groupby("gender"):
            scores = g["score_reps"].sort_values(ascending=False).reset_index(drop=True)
            pct = (scores.index / max(len(scores) - 1, 1)) * 100
            tmp = pd.DataFrame({"percent_of_field": pct, "score_reps": scores, "gender": gender})
            plot_rows.append(tmp)
        pct_df = pd.concat(plot_rows, ignore_index=True)
        fig = px.line(pct_df, x="percent_of_field", y="score_reps", color="gender")
        st.plotly_chart(fig, use_container_width=True)

st.subheader("Leaderboard table")
leaderboard = filtered.sort_values(["gender", "rank_th", "score_reps"], ascending=[True, True, False]).reset_index(drop=True)
st.dataframe(leaderboard, use_container_width=True)
