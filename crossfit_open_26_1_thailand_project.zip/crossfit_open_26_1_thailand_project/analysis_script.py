import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

INPUT_FILE = "Thailand 26.1 - ชีต2 (1).csv"
OUTPUT_DIR = "outputs"
CHART_DIR = os.path.join(OUTPUT_DIR, "charts")

os.makedirs(OUTPUT_DIR, exist_ok=True)
os.makedirs(CHART_DIR, exist_ok=True)

def load_data(path: str) -> pd.DataFrame:
    """Load the raw CSV with a safe encoding fallback."""
    encodings = ["utf-8-sig", "utf-8", "cp874", "latin1"]
    last_error = None
    for enc in encodings:
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception as exc:
            last_error = exc
    raise last_error

def standardize_division(value: str) -> str:
    """Standardize known division labels."""
    if pd.isna(value):
        return value
    value = str(value).strip()
    mapping = {
        "RX": "Rx",
        "Rx": "Rx",
        "Scaled": "Scaled",
        "Foudation": "Foundation",
        "Foundation": "Foundation",
    }
    return mapping.get(value, value)

def clean_rank_table(raw: pd.DataFrame) -> pd.DataFrame:
    """
    Reshape the paired men/women rank table into a long-format analytical dataset.
    Expected raw columns:
    - TH Rank
    - Reps Men
    - Division
    - Reps Women
    - Division Women
    """
    required = {"TH Rank", "Reps Men", "Division", "Reps Women", "Division Women"}
    missing = required - set(raw.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    # Split the table into separate gender tables.
    men = raw.loc[raw["Division"].ne("-"), ["TH Rank", "Reps Men", "Division"]].copy()
    men.columns = ["rank_th", "score_reps", "division_raw"]
    men["gender"] = "Men"

    women = raw.loc[raw["Division Women"].ne("-"), ["TH Rank", "Reps Women", "Division Women"]].copy()
    women.columns = ["rank_th", "score_reps", "division_raw"]
    women["gender"] = "Women"

    # Combine and clean.
    clean = pd.concat([men, women], ignore_index=True)
    clean["rank_th"] = pd.to_numeric(clean["rank_th"], errors="coerce")
    clean["score_reps"] = pd.to_numeric(clean["score_reps"], errors="coerce")
    clean["division"] = clean["division_raw"].apply(standardize_division)

    # Remove rows that still fail core parsing.
    clean = clean.dropna(subset=["rank_th", "score_reps", "division"]).copy()
    clean["rank_th"] = clean["rank_th"].astype(int)

    # Analytical helper fields.
    clean["is_rank_tied"] = clean.duplicated(["gender", "rank_th"], keep=False)
    clean["score_z_within_gender_division"] = clean.groupby(["gender", "division"])["score_reps"].transform(
        lambda s: (s - s.mean()) / (s.std(ddof=0) if s.std(ddof=0) else 1)
    )
    clean["percentile_within_gender"] = (
        clean.groupby("gender")["score_reps"].rank(pct=True, ascending=True, method="average") * 100
    )

    return clean

def analyze(clean: pd.DataFrame) -> dict:
    """Generate reusable summary outputs."""
    result = {}
    result["total_athletes"] = int(len(clean))
    result["by_gender"] = (
        clean.groupby("gender")["score_reps"]
        .agg(["size", "min", "median", "mean", "max", "std"])
        .rename(columns={"size": "athletes"})
        .reset_index()
    )
    result["by_gender_division"] = (
        clean.groupby(["gender", "division"])["score_reps"]
        .agg(["size", "min", "median", "mean", "max", "std"])
        .rename(columns={"size": "athletes"})
        .reset_index()
    )
    result["percentile_cutoffs"] = (
        clean.groupby("gender")["score_reps"]
        .quantile([0.99, 0.95, 0.90, 0.75, 0.50])
        .unstack()
        .rename(columns={
            0.99: "top_1_pct_cutoff",
            0.95: "top_5_pct_cutoff",
            0.90: "top_10_pct_cutoff",
            0.75: "top_25_pct_cutoff",
            0.50: "median"
        })
        .reset_index()
    )
    return result

def make_charts(clean: pd.DataFrame) -> None:
    """Create presentation-ready charts."""
    # 1) Participation by gender and division
    pivot = clean.pivot_table(index="gender", columns="division", values="score_reps", aggfunc="size", fill_value=0)
    ax = pivot.plot(kind="bar", figsize=(8, 5))
    ax.set_title("CrossFit Open 26.1 Thailand - Participation by Gender and Division")
    ax.set_xlabel("Gender")
    ax.set_ylabel("Athlete count")
    ax.legend(title="Division")
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "participation_by_gender_division.png"), dpi=160)
    plt.close()

    # 2) Histogram by gender
    fig, ax = plt.subplots(figsize=(8, 5))
    for gender, group in clean.groupby("gender"):
        ax.hist(group["score_reps"], bins=18, alpha=0.5, label=gender)
    ax.set_title("Score Distribution by Gender")
    ax.set_xlabel("Score (reps)")
    ax.set_ylabel("Athlete count")
    ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "score_distribution_by_gender.png"), dpi=160)
    plt.close()

    # 3) Box plot by gender/division
    data = []
    labels = []
    for gender in ["Men", "Women"]:
        for division in ["Rx", "Scaled", "Foundation"]:
            subset = clean[(clean["gender"] == gender) & (clean["division"] == division)]["score_reps"]
            if len(subset) > 0:
                data.append(subset.values)
                labels.append(f"{gender}\n{division}")
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.boxplot(data, labels=labels)
    ax.set_title("Score Spread by Gender and Division")
    ax.set_ylabel("Score (reps)")
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "boxplot_score_by_gender_division.png"), dpi=160)
    plt.close()

    # 4) Percentile curve
    fig, ax = plt.subplots(figsize=(8, 5))
    for gender, group in clean.groupby("gender"):
        scores = np.sort(group["score_reps"].values)[::-1]
        percentile = np.linspace(0, 100, len(scores))
        ax.plot(percentile, scores, label=gender)
    ax.set_title("Percentile Performance Curve")
    ax.set_xlabel("Percent of field (from top performer to full field)")
    ax.set_ylabel("Score (reps)")
    ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "percentile_curve.png"), dpi=160)
    plt.close()

    # 5) Rank vs score
    fig, ax = plt.subplots(figsize=(8, 5))
    for gender, group in clean.groupby("gender"):
        ax.scatter(group["rank_th"], group["score_reps"], alpha=0.6, label=gender, s=18)
    ax.set_title("Rank vs Score")
    ax.set_xlabel("Thailand rank (1 = best)")
    ax.set_ylabel("Score (reps)")
    ax.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(CHART_DIR, "rank_vs_score.png"), dpi=160)
    plt.close()

def export_outputs(clean: pd.DataFrame, summary: dict) -> None:
    """Export cleaned data and summary tables."""
    clean.to_csv(os.path.join(OUTPUT_DIR, "cleaned_crossfit_open_26_1_thailand.csv"), index=False)
    summary["by_gender"].to_csv(os.path.join(OUTPUT_DIR, "summary_by_gender.csv"), index=False)
    summary["by_gender_division"].to_csv(os.path.join(OUTPUT_DIR, "summary_by_gender_division.csv"), index=False)
    summary["percentile_cutoffs"].to_csv(os.path.join(OUTPUT_DIR, "percentile_cutoffs.csv"), index=False)

def main() -> None:
    raw = load_data(INPUT_FILE)
    clean = clean_rank_table(raw)
    summary = analyze(clean)
    make_charts(clean)
    export_outputs(clean, summary)
    print("Done. Outputs saved in:", OUTPUT_DIR)

if __name__ == "__main__":
    main()
